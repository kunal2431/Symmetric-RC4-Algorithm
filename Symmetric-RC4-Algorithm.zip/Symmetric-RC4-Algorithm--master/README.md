# Symmetric-RC4-Algorithm-
RC4 is basically a bite oriented algorithm or symmetric key cipher. It encrypts laptop files, personal computers &amp; disks.It protects private &amp; confidential data messages sent to and from secure websites.It is also known as vernam cipher. RC4 cipher is extremely fast &amp; uses small amount of ram and It is good for small handheld devices.
